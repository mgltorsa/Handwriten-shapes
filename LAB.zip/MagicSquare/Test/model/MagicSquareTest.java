package model;

import junit.framework.TestCase;

public class MagicSquareTest extends TestCase{
	private MagicSquare magicSquare;
	
	void setupScenary1(){
		magicSquare = new MagicSquare();
	}
	
	
	public void testNoUp() {
		setupScenary1();
		magicSquare.noUp(3, 3);
		int[][] matrix=magicSquare.getMagicSquare();
		int[][] tmp= {{6,1,8},{7,5,3},{2,9,4}};
		
		for (int i = 0; i < tmp.length; i++) {
			for (int j = 0; j < tmp.length; j++) {
				assertTrue(matrix[i][j]==tmp[i][j]);
			}
		}
		
	}

}

