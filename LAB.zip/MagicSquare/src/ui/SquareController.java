package ui;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import model.MagicSquare;

public class SquareController {

	private MagicSquare magicSquare;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ComboBox<String> sence;

	@FXML
	private ComboBox<String> ubication;

	@FXML
	private TextField size;

	@FXML
	private Button launch;

	@FXML
	private GridPane gridPane;

	@FXML
	void initialize() {
		assert sence != null : "fx:id=\"sence\" was not injected: check your FXML file 'Window.fxml'.";
		assert ubication != null : "fx:id=\"ubication\" was not injected: check your FXML file 'Window.fxml'.";
		assert size != null : "fx:id=\"size\" was not injected: check your FXML file 'Window.fxml'.";
		assert launch != null : "fx:id=\"launch\" was not injected: check your FXML file 'Window.fxml'.";
		assert gridPane != null : "fx:id=\"gridPane\" was not injected: check your FXML file 'Window.fxml'.";
		sence.setVisible(true);
		sence.getItems().add("NO");
		sence.getItems().add("NE");
		sence.getItems().add("SO");
		sence.getItems().add("SE");
		ubication.setVisible(false);
		magicSquare=new MagicSquare();
		launch.setText("NEXT");
	} 

	@FXML
	public void fillMagicSquare(ActionEvent event){
		int sizeSquare = Integer.parseInt(size.getText());
		MouseEvent mouse=null;
		addItems(mouse,sence.getValue());
		launch.setText("LAUNCH");
		if(sizeSquare % 2 == 0) {
			Alert alert=new Alert(AlertType.WARNING,"Please enter an odd number",ButtonType.CLOSE);
			alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
			alert.show();
		}else {
			gridPane.getChildren().clear();
			magicSquare.fillSquare(sizeSquare, sence.getValue(), ubication.getValue());
			int[][] square= magicSquare.getMagicSquare();
			for(int i=0;i<sizeSquare;i++) {
				for(int j=0;j<sizeSquare;j++) {
					int number= square[i][j];
					Button buton=new Button(""+number);
					GridPane.setConstraints(buton, i, j, 1, 1);
					gridPane.getChildren().addAll(buton);
				}
			}
		}
	}
	/**
	 * The method adds the options to start the filling, showing all the possible options for each sense
	 * @param ivent
	 * @param option
	 * @return boolean
	 */
	public boolean addItems(MouseEvent ivent, String option) {
		boolean launch=false;
		ubication.setVisible(true);
		if (option.equalsIgnoreCase("NO")) {
			ubication.getItems().add("UP");
			ubication.getItems().add("LEFT");
			launch = true;
		} else if (option.equalsIgnoreCase("NE")) {
			ubication.getItems().add("UP");
			ubication.getItems().add("RIGHT");
			launch = true;
		} else if (option.equalsIgnoreCase("SO")) {
			ubication.getItems().add("LEFT");
			ubication.getItems().add("DOWN");
			launch = true;
		} else if (option.equalsIgnoreCase("SE")) {
			ubication.getItems().add("DOWN");
			ubication.getItems().add("RIGHT");
			launch = true;
		}
		return launch;
	}
}
